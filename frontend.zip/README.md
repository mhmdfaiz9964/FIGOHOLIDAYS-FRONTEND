# 🌴 Figo Holidays - Almusafir Sri Lanka

[![React](https://img.shields.io/badge/React-19.2-blue?logo=react)](https://reactjs.org/)
[![Vite](https://img.shields.io/badge/Vite-6.2-purple?logo=vite)](https://vitejs.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-blue?logo=typescript)](https://www.typescriptlang.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A modern, high-performance travel and tourism web application built for **Figo Holidays**. This platform showcases the beauty of Sri Lanka, offering tour packages, hotel bookings, transportation services, and visa assistance.

---

## ✨ Features

- 🚀 **Lightning Fast**: Built with Vite and React 19 for optimal performance.
- 📱 **Fully Responsive**: Seamless experience across mobile, tablet, and desktop.
- 🗺️ **Interactive Discovery**: Explore destinations, tour packages, and hotels.
- 🔌 **Dynamic API Integration**: Powered by a robust backend API for real-time data.
- 💬 **WhatsApp Integration**: Quick communication through a floating WhatsApp button.
- 📄 **SEO Optimized**: Semantic HTML and clean metadata.
- 🎨 **Modern UI/UX**: Clean, elegant design using Tailwind CSS.

---

## 🛠️ Tech Stack

- **Frontend Framework**: [React 19](https://react.dev/)
- **Build Tool**: [Vite 6](https://vitejs.dev/)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **Routing**: [React Router 7](https://reactrouter.com/)
- **Styling**: Tailwind CSS
- **API Communication**: Native Fetch API with structured `api.ts` service

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (Latest LTS recommended)
- [npm](https://www.npmjs.com/)

### Installation

1. **Clone the repository:**

   ```bash
   git clone https://github.com/mhmdfaiz9964/FIGOHOLIDAYS-FRONTEND.git
   cd FIGOHOLIDAYS-FRONTEND
   ```

2. **Install dependencies:**

   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   Create a `.env.local` file in the root directory:

   ```env
   VITE_API_BASE_URL=http://your-backend-api.com/api/v1
   ```

4. **Start the development server:**
   ```bash
   npm run dev
   ```

---

## 📦 Project Structure

```text
frontend/
├── src/
│   ├── components/    # Reusable UI components (Navbar, Footer, etc.)
│   ├── pages/         # Full page components (Home, Hotels, About, etc.)
│   ├── data/          # Local data and mock data
│   ├── types.ts       # TypeScript interfaces and types
│   ├── api.ts         # API service layer
│   └── App.tsx        # Root component and Routing
├── public/            # Static assets
└── index.html         # Entry point
```

---

## 🏗️ Available Scripts

| Script            | description                                                      |
| :---------------- | :--------------------------------------------------------------- |
| `npm run dev`     | Starts the development server with Hot Module Replacement (HMR). |
| `npm run build`   | Compiles the application for production.                         |
| `npm run preview` | Locally previews the production build.                           |

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

<p align="center">Made with ❤️ for Figo Holidays</p>
